import Styled from "styled-components";

export const  StyledMusicDetail = Styled.div`
display: grid;
align-items: center;
// backgroundColor:red;
margin-left:20px
`