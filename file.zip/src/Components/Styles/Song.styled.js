import styled from 'styled-components'

export const StyleSong = styled.div`
  background: lightgray;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 5px;
  padding: 10px;
  
  
`