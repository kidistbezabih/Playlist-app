import styled from 'styled-components'

export const StyledHeader = styled.div`
color: green;
display: flex;
align-items: center;
justify-content: space-between;
background: grey;
margin-bottom:10px;
padding: 2%;
`