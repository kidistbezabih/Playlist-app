import styled from "styled-components";

export const StyledPlay = styled.div`
  display: flex;
  width: 98%;
  background:dark-gray;
  margin:auto


`