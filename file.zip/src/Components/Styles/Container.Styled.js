import styled from 'styled-components';

export const Container = styled.div`
width: 100%;
margin: auto;
// padding: 2%;
background: #ebfbff;
// padding: 10px;
`
