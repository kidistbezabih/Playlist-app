import {StyledMusicDetail} from './Styles/MusicDetail.Styled'

const MusicDetail = ({ song }) => {
  return (
    <StyledMusicDetail>
      <h3>
        {song.song}
      </h3>
      <h5>
        {song.singer}
      </h5>
    </StyledMusicDetail>
  )
}

export default MusicDetail