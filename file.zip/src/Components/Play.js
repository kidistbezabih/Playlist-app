import { FaPlay } from 'react-icons/fa';
import MusicDetail from './MusicDetail'
import { StyledPlay } from './Styles/Play.Styled'


const Play = ({ song }) => {
  return (
    <StyledPlay>
        <button>
          <FaPlay/>
        </button>

        <MusicDetail song={song}/>
    </StyledPlay>
  )
}

export default Play
